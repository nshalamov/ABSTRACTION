package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String cardName = scan.nextLine();
        String cardSuit = scan.nextLine();
        Card card = new Card(CardRank.valueOf(cardName), CardSuit.valueOf(cardSuit));

        System.out.printf("Card name: %s of %s; Card power: %d",
                cardName, cardSuit, card.getPower());
    }
}