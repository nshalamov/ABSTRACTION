package TrafficLight;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String[] lights = scan.nextLine().split("\\s+");
        int changes = Integer.parseInt(scan.nextLine());

        List<TrafficLights> trafficLights = new ArrayList<>();

        for(String light : lights) {
            TrafficLights trafficLight = new TrafficLights(Lights.valueOf(light));
            trafficLights.add(trafficLight);
        }

        for (int i = 0; i < changes; i++) {
            for(TrafficLights light : trafficLights) {
                light.update();
                System.out.print(light.getLight() + " ");
            }
            System.out.println();
        }
    }
}
