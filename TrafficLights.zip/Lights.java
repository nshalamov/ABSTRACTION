package TrafficLight;

public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
