package refactor;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    static long ivoPoints = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //read dimensions
        int[] dimensions = readArray(scanner.nextLine());
        //create a matrix
        Matrix matrix = new Matrix(dimensions);
        matrix.fillMatrix();

        String command = scanner.nextLine();
        while (!command.equals("Let the Force be with you")) {
            int[] ivoCoordinates = readArray(command);
            int[] evilCoordinates = readArray(scanner.nextLine());
            int rowEvil = evilCoordinates[0];
            int colEvil = evilCoordinates[1];
            int rowIvo = ivoCoordinates[0];
            int colIvo = ivoCoordinates[1];

            matrix.evilMove(rowEvil, colEvil);
            ivoPoints += matrix.ivoMove(rowIvo, colIvo);
            command = scanner.nextLine();
        }

        System.out.println(ivoPoints);
    }

    private static int[] readArray(String command) {
        return Arrays.stream(command.split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();
    }
}