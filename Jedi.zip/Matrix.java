package refactor;

public class Matrix {
    private int[][] matrix;
    private int[] dimensions;

    public Matrix(int[] dimensions) {
        this.dimensions = dimensions;
        this.matrix = new int[this.dimensions[0]][this.dimensions[1]];
    }

    public void fillMatrix() {
        int value = 0;
        for (int i = 0; i < this.dimensions[0]; i++) {
            for (int j = 0; j < this.dimensions[1]; j++) {
                matrix[i][j] = value++;
            }
        }
    }

    public int getLength() {
        return this.matrix.length;
    }

    public int getWidth() {
        return this.matrix[0].length;
    }

    public void destroy(int row, int col) {
        this.matrix[row][col] = 0;
    }

    public int getPoints(int row, int col) {
        return this.matrix[row][col];
    }

    public void evilMove(int row, int col) {
        while (row >= 0 && col >= 0) {
            if (row < getLength() && col < getWidth()) {
                destroy(row, col);
            }
            row--;
            col--;
        }
    }

    public long ivoMove(int row, int col) {
        long points = 0;
        while (row >= 0 && col < getWidth()) {
            if (row < getLength() && col >= 0 && col < getWidth()) {
                points += getPoints(row, col);
            }

            row--;
            col++;
        }

        return points;
    }
}
